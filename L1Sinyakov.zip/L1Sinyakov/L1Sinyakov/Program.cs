﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1Sinyakov
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Первая задача

            double e;
            double r;
            double t;

            Console.WriteLine("Задание N1, Анкета");
            Console.WriteLine("Введите Ваше имя");
            string q = Console.ReadLine();

            Console.WriteLine("Введите Вашу фамилию");
            string w = Console.ReadLine();

            Console.WriteLine("Введите Ваш возраст ");
            string imputNumberE = Console.ReadLine();
            e = Convert.ToDouble(imputNumberE);

            Console.WriteLine("Введите Ваш рост");
            string imputNumberR = Console.ReadLine();
            r = Convert.ToDouble(imputNumberR);

            Console.WriteLine("Введите Ваш вес");
            string imputNumberT = Console.ReadLine();
            t = Convert.ToDouble(imputNumberT);

            Console.WriteLine("Ваша анкета: " + " Имя: " + q + " Фамилия: " +  w + " Ваш возраст: " + e + " Ваш Рост: " + r + " Ваш вес: " + t);
            Console.WriteLine("Ваша анкета: Имя: {0}  Фамилия: {1} Ваш возраст: {2:F0} Ваш Рост: {3:F2} Ваш вес: {4:F2}", q, w, e, r, t);
            Console.WriteLine($"Ваша анкета: Имя: {q}  Фамилия: {w} Ваш возраст: {e:F0} Ваш Рост: {r:F2} Ваш вес: {t:F2}");
            Console.ReadLine();
            Console.Clear();

            #endregion

            #region Вторая задача

            double m;
            double h;


            Console.WriteLine("Задание N2, Рассчитать и вывести индекс массы тела");

            Console.WriteLine("Введите массу тела ");
            string imputNumberM = Console.ReadLine();
            m = Convert.ToDouble(imputNumberM);

            Console.WriteLine("Введите рост ");
            string imputNumberH = Console.ReadLine();
            h = Convert.ToDouble(imputNumberH);

            double i = m / (h * h);

            Console.WriteLine($"Индекс массы тела: {i}");
            Console.ReadLine();
            Console.Clear();

            #endregion

            #region Третья задача

            double x;
            double c;
            double y;
            double u;


            Console.WriteLine("Введите значение координат x1 ");
            string imputNumberX = Console.ReadLine();
            x = Convert.ToDouble(imputNumberX);

            Console.WriteLine("Введите значение координат y1 ");
            string imputNumberY = Console.ReadLine();
            y = Convert.ToDouble(imputNumberY);

            Console.WriteLine("Введите значение координат x2 ");
            string imputNumberC = Console.ReadLine();
            c = Convert.ToDouble(imputNumberC);

            Console.WriteLine("Введите значение координат y2 ");
            string imputNumberU = Console.ReadLine();
            u = Convert.ToDouble(imputNumberU);

            double s = c - x;

            double v = u - y;


            double z = Math.Pow(s, 2) + Math.Pow(v, 2);


            double p = Math.Sqrt(z);



            Console.WriteLine($"Индекс массы тела: {p} ");
            Console.ReadLine();
            Console.Clear();

            #endregion 
            Console.ReadLine();

        }
    }
}
